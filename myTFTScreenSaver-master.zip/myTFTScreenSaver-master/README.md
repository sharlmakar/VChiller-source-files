# myTFTScreenSaver
A screen saver script for Arduino UNO TFT Touch Screen
